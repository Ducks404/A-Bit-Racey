HI
This is my first game ever 

The actual game is the A Bit Racey.exe 

Make a shortcut of the executable file onto somewhere and you can play it easily