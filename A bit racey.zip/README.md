My First Game
=======================

I made this game after following [Sentdex's pygame tutorial](https://youtube.com/playlist?list=PLQVvvaa0QuDdLkP8MrOXLe_rKuf6r80KO) on youtube

I made this in ```2017/2018``` at 5th grade but I'm adding this into my repository to practice my git

*The original_README.txt was the README file I made when I first made the game*